-- Purpose:     show plan for statement in AWR history
set lines 155
set pages 9999
SELECT * FROM table(dbms_xplan.display_awr('&sql_id',nvl('&plan_hash_value',null),null,'ADVANCED +ALLSTATS LAST +MEMSTATS LAST'))
/
